export const dataFAQ = [{
        ques : "wonder-ques-1",
        answer : "wonder-ans-1"
    },{
        ques : "wonder-ques-2",
        answer : "wonder-ans-2"
    },{
        ques : "wonder-ques-3",
        answer : "wonder-ans-3"
    },{
        ques : "wonder-ques-4",
        answer : "wonder-ans-4"
    },{
        ques : "wonder-ques-5",
        answer : "wonder-ans-5"
    },{
        ques : "wonder-ques-6",
        answer : "wonder-ans-6"
    }]
