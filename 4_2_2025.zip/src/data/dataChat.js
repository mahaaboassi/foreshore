// export const chatData =[
//     {
//         sender : "support",
//         key : "hospitality",
//         id : 1,
//         content : <div>Please select the question you'd like to explore.</div>,
//         answer : <></>
//     },
//     {
//         sender : "support",
//         key : "question",
//         id : 2,
//         content : <div>How do I apply for this property?</div>,
//         answer : <div>1_Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab sit aperiam explicabo quis inventore, praesentium fuga nihil sed dolorum magni, ea doloremque culpa eius error molestiae sequi animi eum neque </div>
//     },
//     {
//         sender : "support",
//         key : "question",
//         id : 3,
//         content : <div>2 How do I apply for this property?</div>,
//         answer : <div>2_Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab sit aperiam explicabo quis inventore, praesentium fuga nihil sed dolorum magni, ea doloremque culpa eius error molestiae sequi animi eum neque </div>
//     },
//     {
//         sender : "support",
//         key : "question",
//         id : 4,
//         content : <div>3 How do I apply for this property?</div>,
//         answer : <div>3_Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab sit aperiam explicabo quis inventore, praesentium fuga nihil sed dolorum magni, ea doloremque culpa eius error molestiae sequi animi eum neque </div>
//     },
//     {
//         sender : "support",
//         key : "question",
//         id : 5,
//         content : <div>4 How do I apply for this property?</div>,
//         answer : <div>4_Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab sit aperiam explicabo quis inventore, praesentium fuga nihil sed dolorum magni, ea doloremque culpa eius error molestiae sequi animi eum neque </div>
//     },
//     {
//         sender : "support",
//         key : "no-option",
//         id :100,
//         content : "No Option",
//         answer : "3_Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab sit aperiam explicabo quis inventore, praesentium fuga nihil sed dolorum magni, ea doloremque culpa eius error molestiae sequi animi eum neque?"
//     },

// ]
   
// //  {
// //     sender : "support",
// //     key : "finish",
// //     id :101,
// //     option : "Thanks for your intersted",
// //     answer : ""
// // },
// // {
// //     sender : "support",
// //     key : "finish-support",
// //     id :101,
// //     option : "Thanks for your intersted, we well be back later",
// //     answer : ""
// // },
export const chatData =[
    {
        sender : "support",
        key : "book",
        id : 2,
        content : <div>Book Your Property</div>,
        answer : <div>Please leave your Name, Number, and Email. One of our property specialists will Get back to you.</div>
    },
    {
        sender : "support",
        key : "list",
        id : 3,
        content : <div>List Your Property</div>,
        answer : <div>Please leave your Name, Number, and Email. One of our property specialists will Get back to you.</div>
    },


]
   


