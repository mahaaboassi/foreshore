export const contactData = {
    call : "+971 04 2281609" ,
    facebook : "https://www.facebook.com/profile.php?id=61553204535892",
    instagram : "https://www.instagram.com/foreshoreuae/",
    linkedin : "https://www.linkedin.com/company/foreshoreuae/",
    whatsapp : "+971 55 615 2063",
    email : "info@foreshore.ae",
    location_ar : "المكتب 609، مبنى البيان، مجمع دبي للاستثمار - 1، دبي، الإمارات العربية المتحدة",
    location_en : "Office 609, Al Bayan Building, Dubai Investments Park - 1, Dubai, UAE",
    map : "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3616.0633505688365!2d55.170182574831!3d24.99796323974274!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f43e8b051b1c5%3A0x22c2903666b955be!2sForeshore%20Vacation%20Home%20Rentals%20LLC!5e0!3m2!1sen!2sae!4v1736317607736!5m2!1sen!2sae"
}