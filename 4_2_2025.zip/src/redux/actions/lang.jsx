export const ChangeLang = ({lang}) => {
    return{
        type: "CHANGE-LANGUAGE",
        lang : lang,
    }
}