export const ChangeChat = ({isOpen}) => {
    return{
        type: "CHANGE-SUPPORT-STATUS",
        isOpen : isOpen,
    }
}